﻿using FudgTeamMiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FudgTeamMiniProject.Repository
{
    public class RepositoryClass : IRepository
    {
        FudGPortalContext context;
        public RepositoryClass(FudGPortalContext _context)
        {
            context = _context;
        }
        public bool AddCustomer(Customer customer)
        {
            context.Customers.Add(customer);
            context.SaveChanges();
            return true;
        }

        public bool AddFood(Food food)
        {
            context.Foods.Add(food);
            context.SaveChanges();
            return true;
        }

        public bool AddOrder(OrderFood orderFood)
        {
            context.OrderFoods.Add(orderFood);
            context.SaveChanges();
            return true;
        }

        public bool AddRestaurant(Restaurant restaurant)
        {
            context.Restaurants.Add(restaurant);
            context.SaveChanges();
            return true;
        }

        public bool DeleteRestaurant(int id)
        {
            var res = context.Restaurants.Find(id);
            context.Restaurants.Remove(res);
            context.SaveChanges();
            return true;
        }

        public Customer GetCustomer(string email)
        {
            var res = context.Customers.First(p => p.Emailid == email);
            return res;
        }

        public Food GetFood(int id)
        {
            var res = context.Foods.Find(id);
            return res;
        }

        public Restaurant GetRestaurant(int id)
        {
            var res = context.Restaurants.Find(id);
            return res;
        }

        public List<Restaurant> GetRestaurants()
        {
            var list=context.Restaurants.ToList();
            return list;
        }

        public bool UpdateCustomer(int id, Customer customer)
        {
            context.Entry(customer).State = EntityState.Modified;
            context.SaveChanges();
            return true;
        }

        public bool UpdateFood(int id, Food food)
        {
            context.Entry(food).State = EntityState.Modified;
            context.SaveChanges();
            return true;
        }

        List<Food> IRepository.GetFoodd(int resid)
        {
            if (context != null)
            {
                return (from f in context.Foods
                        where f.Resid == resid
                        select new Food
                        {
                            Foodid = f.Foodid,
                            Title = f.Title,
                            Description = f.Description,
                            Price = f.Price,
                            Resid = f.Resid
                        }).ToList();
            }
            return null;
        }
    }
}
