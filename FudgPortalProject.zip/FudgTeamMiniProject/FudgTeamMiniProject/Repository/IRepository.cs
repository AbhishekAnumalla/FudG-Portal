﻿using FudgTeamMiniProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FudgTeamMiniProject.Repository
{
    public interface IRepository
    {
        bool AddRestaurant(Restaurant restaurant);
        bool DeleteRestaurant(int id);
        Restaurant GetRestaurant(int id);
        List<Restaurant> GetRestaurants();
        bool AddFood(Food food);
        bool UpdateFood(int id, Food food);
        Food GetFood(int id);
        bool AddCustomer(Customer customer);
        bool UpdateCustomer(int id,Customer customer);
        Customer GetCustomer(string email);
        bool AddOrder(OrderFood orderFood);
        List<Food> GetFoodd(int resid);
    }
}
