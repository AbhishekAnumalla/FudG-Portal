﻿using FudgTeamMiniProject.Models;
using FudgTeamMiniProject.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FudgTeamMiniProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodController : ControllerBase
    {
        IRepository service;
        public FoodController(IRepository _service)
        {
            service = _service; 
        }

        [Authorize(Roles = "Restaurant")]
        [HttpPost]
        public IActionResult Post(Food food)
        {
            try
            {
                service.AddFood(food);
                return Ok("Food item added to the menu");
            }
            catch
            {
                return BadRequest("Error, couldn't add this food item to the menu!");
            }
        }

        [Authorize(Roles = "Restaurant")]
        [HttpPut]
        public IActionResult Put(int id,Food food)
        {
            try
            {
                service.UpdateFood(id,food);
                return Ok("Food details updated!");
            }
            catch
            {
                return BadRequest("Error occurred while trying to update the food price.");
            }
        }

        [Authorize(Roles = "Restaurant,Customer")]
        [HttpGet]
        public IActionResult Get(int id)
        {
            try
            {
                var res = service.GetFood(id);
                return Ok(res);
            }
            catch
            {
                return BadRequest("Error occured trying to fetch the details for the food id: "+id);
            }
        }


    }
}
