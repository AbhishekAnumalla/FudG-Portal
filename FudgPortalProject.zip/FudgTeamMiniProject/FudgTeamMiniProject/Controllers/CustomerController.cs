﻿using FudgTeamMiniProject.Models;
using FudgTeamMiniProject.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FudgTeamMiniProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        IRepository service;
        public CustomerController(IRepository _service)
        {
            service = _service;
        }

        [Authorize(Roles = "Customer")]
        [HttpGet("{email}")]
        public IActionResult Get(string email)
        {
            try
            {
                var res=service.GetCustomer(email);
                return Ok(res);
            }
            catch
            {
                return BadRequest("Unable to fetch details at this time.");
            }
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Post(Customer customer)
        {
            try
            {
                service.AddCustomer(customer);
                return Ok("Customer successfully registered");
            }
            catch
            {
                return BadRequest("Unable to register customer at this time");
            }
        }

        [Authorize(Roles = "Customer")]
        [HttpPut]
        public IActionResult Put(int id, Customer customer)
        {
            try
            {
                service.UpdateCustomer(id,customer);
                return Ok("Updated successfully.");
            }
            catch
            {
                return BadRequest("Unable to update customer details.");
            }
        }

        
    }
}
