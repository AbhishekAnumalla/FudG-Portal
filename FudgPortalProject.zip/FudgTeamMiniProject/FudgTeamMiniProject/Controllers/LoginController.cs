﻿using FudgTeamMiniProject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace FudgTeamMiniProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration _config;

        public LoginController(IConfiguration config)
        {
            _config = config;
        }
        FudGPortalContext context = new FudGPortalContext();

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login([FromBody] LoginModel login)
        {
            IActionResult response = Unauthorized();
            var user = AuthenticateUser(login);

            if (user != null)
            {
                var tokenString = GenerateJSONWebToken(user);
                user.token = tokenString;
                response = Ok(user);
            }
            return response;
        }

        private string GenerateJSONWebToken(LoginModel userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                  new Claim(ClaimTypes.Role,userInfo.role)
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddMinutes(120),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private LoginModel AuthenticateUser(LoginModel login)
        {
            LoginModel user = null;
            //Validate the user credentials
            var value = context.Customers.Any(p => p.Emailid.Equals(login.email) & p.Password.Equals(login.password));
            var customer = context.Customers.FirstOrDefault(p => p.Emailid.Equals(login.email) & p.Password.Equals(login.password));
            var restaurant = context.Restaurants.FirstOrDefault(p => p.Email.Equals(login.email) & p.Respassword.Equals(login.password));

            if (login.email == "admin@fudg.com" && login.password == "adminfudg")
            {
                user = new LoginModel { email = "admin@fudg.com", password = "adminfudg", role = "Admin" };
            }

            else if (value)
            {
                {
                    user = new LoginModel { email = login.email, password = login.password, role = "Customer", id = customer.Customerid };
                }
            }
            else if(restaurant!=null)
            {
                user = new LoginModel { email = login.email, password = login.password, role = "Restaurant", id=restaurant.Resid};
            }

            return user;
        }

    }
}
