﻿using FudgTeamMiniProject.Models;
using FudgTeamMiniProject.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FudgTeamMiniProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantsController : ControllerBase
    {
        IRepository service;
        public RestaurantsController(IRepository _service)
        {
            service = _service;
        }

        [Authorize(Roles ="Admin, Customer")]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var res = service.GetRestaurants();
                return Ok(res);
            }
            catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Post(Restaurant restaurant)
        {
            try
            {
                service.AddRestaurant(restaurant);
                return Ok("Restaurant added!");
            }
            catch
            {
                return BadRequest("Error occurred while trying to add the restaurants.");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            try
            {
                service.DeleteRestaurant(id);
                return Ok("Restaurant deleted successfully");
            }
            catch
            {
                return BadRequest("Error. Could not delete the restaurant.");
            }
        }

        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var res = service.GetRestaurant(id);
                return Ok(res);
            }
            catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
