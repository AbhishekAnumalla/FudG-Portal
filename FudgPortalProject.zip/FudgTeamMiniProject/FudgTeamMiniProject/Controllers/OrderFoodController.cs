﻿using FudgTeamMiniProject.Models;
using FudgTeamMiniProject.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FudgTeamMiniProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderFoodController : ControllerBase
    {
        IRepository service;
        public OrderFoodController(IRepository _service)
        {
            service = _service;
        }

        [Authorize(Roles = "Customer")]
        [HttpPost]
        public IActionResult Post(OrderFood orderFood)
        {
            try
            {
                service.AddOrder(orderFood);
                return Ok("Ordered placed successfully!");
            }
            catch
            {
                return BadRequest("Error occurred while placing the order.");
            }
        }

        /*[Authorize(Roles = "Customer")]*/
        [HttpGet("{resid}")]
        public IActionResult Get(int resid)
        {
            try
            {
                var res=service.GetFoodd(resid);
                return Ok(res);
            }
            catch
            {
                return BadRequest("Error while retrieving data");
            }
        }



    }
}
